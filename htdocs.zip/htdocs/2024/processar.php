<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "bd_contato";


$conn = new mysqli($servidor, $usuario, $senha, $banco);


if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}


$nome = $conn->real_escape_string($_POST['name']);
$email = $conn->real_escape_string($_POST['email']);
$mensagem = $conn->real_escape_string($_POST['message']);


$stmt = $conn->prepare("INSERT INTO contato (nome, email, mensagem) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $nome, $email, $mensagem);


if ($stmt->execute()) {
    echo "Mensagem enviada com sucesso!";
} else {
    echo "Erro ao enviar mensagem: " . $stmt->error;
}


$stmt->close();
$conn->close();
?>